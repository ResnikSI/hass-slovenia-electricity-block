"""Constants for the Slovenia Electricity Block integration."""

DOMAIN = "slo_electricity_block"
